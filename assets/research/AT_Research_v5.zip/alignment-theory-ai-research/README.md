# Alignment Theory AI Alignment Research Corpus

Author: Michael Bower  
Website: https://alignmenttheory.org  
Version: v1.1  
Updated: April 27, 2026

## Overview

This repository contains the Alignment Theory AI Alignment Research Corpus, a research program focused on behavioral drift detection, objective anchoring, runtime realignment, participatory capacity preservation, and production AI governance.

The core thesis is:

> Alignment is not only whether an output is acceptable; alignment is whether the system remains ordered toward its intended objective over time.

## Core Papers

1. Executive Summary
2. Three-Layer Blueprint for AI Alignment
3. Participatory Capacity Preservation Index (PCPI)
4. Literature Review and Drift Detection Gap
5. Competitive Positioning
6. Who This Is For
7. Real Case Methodology
8. Formal Glossary
9. Framework Evolution and Research Lineage
10. Limitations, Critiques, and Open Problems
11. Empirical Drift Casebook

## PCPI

The Participatory Capacity Preservation Index (PCPI) is a proposed 0-100 scoring framework for evaluating whether AI responses preserve or erode human participation.

PCPI measures positive participation features:

- final judgment retention
- reasoning scaffolding
- alternatives and tradeoffs
- user context integration
- verification path
- skill transfer
- appropriate automation

It subtracts collapse penalties:

- over-decision
- substitute tone
- premature closure
- hidden black-box reasoning
- dependency reinforcement
- normative pressure

Formula:

PCPI = clamp((PositiveParticipation * 100) - (CollapsePenalty * 60), 0, 100)

## Status

This is an active research corpus. PCPI v1 is a proposed measurement framework and has not yet completed formal external validation. Current limitations include:

- human validation pending
- inter-rater reliability study pending
- penalty weights not yet empirically tuned
- domain-specific calibration still required
- LLM-judge calibration in progress

## Citation

Please cite the corpus as:

Bower, M. (2026). Alignment Theory AI Alignment Research Corpus: Behavioral Drift Detection, Realignment Architecture, and AI Governance. AlignmentTheory.org.

See CITATION.cff or https://alignmenttheory.org/pages/how-to-cite.html.